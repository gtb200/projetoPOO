package projecto;

public class Projecto {
    private String nome;
    private String acronimo;
    private Data dataInicio;
    private int duracao;
    private Data dataFim;
}
