package projecto;

import java.util.GregorianCalendar;

public class Doutorado extends Bolseiro {
    protected int custoMensal=1200;

    public Doutorado(GregorianCalendar inicio, GregorianCalendar fim, String nome, String email) {
        super(inicio, fim, nome, email);
    }
}
    

