package projecto;

public class Doutorado extends Bolseiro {
    protected int custoMensal=1200;

    public Doutorado(Data inicio, Data fim, String nome, String email, int custoMensal) {
        super(inicio, fim, nome, email);
        this.custoMensal = custoMensal;
    }
}
    

