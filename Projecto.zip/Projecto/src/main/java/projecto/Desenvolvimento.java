package projecto;

public class Desenvolvimento extends Tarefa {
    protected double taxaEsforco;

    public Desenvolvimento(double taxaEsforco, Data inicio, double duracao, double taxaExecucao, Data fim, String pessoaResponsavel) {
        super(inicio, duracao, taxaExecucao, fim, pessoaResponsavel);
        this.taxaEsforco = 1;
    }


    

}
