package projecto;

public class Mestre extends Bolseiro{

    protected int custoMensal=1000;
    private Docente orientador;


    public Mestre(Data inicio, Data fim, String nome, String email, int custoMensal, Docente orientador) {
        super(inicio, fim, nome, email);
        this.custoMensal = custoMensal;
        this.orientador = orientador;
    }
}
