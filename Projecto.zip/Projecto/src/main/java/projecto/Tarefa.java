package projecto;

public abstract class Tarefa{
    private Data inicio;
    private double duracao;
    private double taxaExecucao;
    private Data fim;
    private String pessoaResponsavel;

    public Tarefa() {
    }
    

    public Tarefa(Data inicio, double duracao, double taxaExecucao, Data fim, String pessoaResponsavel) {
        this.inicio = inicio;
        this.duracao = duracao;
        this.taxaExecucao = taxaExecucao;
        this.fim = fim;
        this.pessoaResponsavel = pessoaResponsavel;
    }


 }
