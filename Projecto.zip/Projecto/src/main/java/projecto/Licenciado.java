package projecto;

public class Licenciado extends Bolseiro {
    protected int custoMensal=800;
    private Docente orientador;


    public Licenciado(Data inicio, Data fim, String nome, String email, Docente orientador) {
        super(inicio, fim, nome, email);
        this.custoMensal = custoMensal;
        this.orientador = orientador;
    }


}
