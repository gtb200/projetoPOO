package projecto;

import java.io.Serializable;

public abstract class Bolseiro extends Pessoa implements Serializable {
    private Data inicio;
    private Data fim;

    public Bolseiro(Data inicio, Data fim, String nome, String email) {
        super(nome, email);
        this.inicio = inicio;
        this.fim = fim;
    }

    public Bolseiro() {

    }


    public Data getInicio() {
        return inicio;
    }

    public void setInicio(Data inicio) {
        this.inicio = inicio;
    }

    public Data getFim() {
        return fim;
    }

    public void setFim(Data fim) {
        this.fim = fim;
    }
    
    
    
    
}
