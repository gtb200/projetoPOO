/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecto;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class GUI {
    CISUC cisuc;

    public GUI(CISUC cisuc) {
        this.cisuc = cisuc;
    }

    JFrame framePrincipal = new JFrame();
    /////////////
    JButton verPerfis = new JButton("Listar Bolseiros");
    JButton verProjetos = new JButton("Listar Projetos");
    JButton verDocentes = new JButton("Listar Docentes");
    JButton save = new JButton("Save and exit");
    ///////////////
    JButton verInformacoes = new JButton("Ver informações do perfil");
    JButton criarPerfil = new JButton("Adicionar perfil");
    JButton criarPerfilDocente = new JButton("Adicionar Docente");
    JButton verInformacoesDocente = new JButton("Ver informaçoes");
    JButton voltar = new JButton("Voltar");
    ////////////////
    JButton botaoVoltarListaDocentes = new JButton("Voltar");
    JButton botaoMakeDocente = new JButton("Criar");
    ////////////////
    JList listaPrincipal = new JList(new DefaultListModel<>());



    ////////////////
    JTextField caixaNome = new JTextField(40);
    JTextField caixaEmail = new JTextField(40);
    JTextField caixaMeca = new JTextField(40);
    JTextField caixaArea = new JTextField(40);
    ////////////////
    JLabel labelNome = new JLabel("Nome:");
    JLabel labelEmail = new JLabel("Email:");
    JLabel labelMeca = new JLabel("Numero mecanográfico:");
    JLabel labelArea = new JLabel("Área de investigação:");
    JLabel labelCriarDocenteTitulo = new JLabel("Criar Docente:");
    ////////////////
    JScrollPane scrollerPrincipal = new JScrollPane(listaPrincipal);

    ////////////////
    JPanel panelPrincipal = new JPanel();
    ////////////////
    JPanel painelAbsolutoPrincipal = new JPanel(null);
    JPanel painelPerfilInformacao = new JPanel(null);
    JPanel painelDocentes = new JPanel(null);
    JPanel painelcriarDocente = new JPanel(null);

    public void paginaPrincipal() {
        panelPrincipal.removeAll();
        panelPrincipal.setLayout(new BorderLayout());


        framePrincipal.setTitle("CISUC");
        framePrincipal.setSize(1200, 900);
        framePrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        verPerfis.setBounds(400, 150, 400, 75);
        verDocentes.setBounds(400, 275, 400, 75);
        verProjetos.setBounds(400, 400, 400, 75);
        save.setBounds(400, 675, 400, 75);

        verPerfis.addActionListener(new verPerfisListener());
        verDocentes.addActionListener(new docentesInformacao());

        painelAbsolutoPrincipal.add(verPerfis);
        painelAbsolutoPrincipal.add(verDocentes);
        painelAbsolutoPrincipal.add(verProjetos);
        painelAbsolutoPrincipal.add(save);

        panelPrincipal.add(painelAbsolutoPrincipal, BorderLayout.CENTER);

        framePrincipal.add(panelPrincipal);
        framePrincipal.setVisible(true);
        panelPrincipal.updateUI();
    }

    public void botaoVerPerfis() {
        scrollerPrincipal.setBounds(400, 150, 400, 450);
        verInformacoes.setBounds(400, 600, 400, 75);
        criarPerfil.setBounds(400, 675, 400, 75);
        voltar.setBounds(400, 750, 400, 75);

        voltar.addActionListener(new voltarListener());

        painelPerfilInformacao.add(voltar);
        painelPerfilInformacao.add(verInformacoes);
        painelPerfilInformacao.add(criarPerfil);
        painelPerfilInformacao.add(scrollerPrincipal);

        panelPrincipal.removeAll();
        panelPrincipal.add(painelPerfilInformacao, BorderLayout.CENTER);
        panelPrincipal.updateUI();
    }

    public void botaoDocentes() {
        voltar.setBounds(400, 750, 400, 75);
        verInformacoesDocente.setBounds(400, 600, 400, 75);
        criarPerfilDocente.setBounds(400, 675, 400, 75);

        voltar.addActionListener(new voltarListener());
        criarPerfilDocente.addActionListener(new criarDocenteListener());
        DefaultListModel listaDocenteObjetos = new DefaultListModel();

        listaDocenteObjetos.addElement(cisuc.listaDocentes);


        JList docenteLista = new JList(listaDocenteObjetos);
        JScrollPane scrollerDocentes = new JScrollPane(docenteLista);
        scrollerDocentes.setBounds(400, 150, 400, 450);
        docenteLista.setBounds(400,150,400,450);
        scrollerDocentes.add(docenteLista);
        painelDocentes.add(docenteLista);
        painelDocentes.add(voltar);
        painelDocentes.add(criarPerfilDocente);
        painelDocentes.add(verInformacoesDocente);
        panelPrincipal.removeAll();
        panelPrincipal.add(painelDocentes,BorderLayout.CENTER);
        painelDocentes.updateUI();
        panelPrincipal.updateUI();
    }

    public void botaoCriarDocente() {

        labelCriarDocenteTitulo.setBounds(50, 50, 100, 50);
        labelNome.setBounds(50, 125, 50, 25);
        labelEmail.setBounds(50, 175, 50, 25);
        labelMeca.setBounds(50, 225, 150, 25);
        labelArea.setBounds(50, 275, 150, 25);

        caixaNome.setBounds(200, 125, 225, 25);
        caixaEmail.setBounds(200, 175, 225, 25);
        caixaMeca.setBounds(200, 225, 225, 25);
        caixaArea.setBounds(200, 275, 225, 25);

        botaoVoltarListaDocentes.setBounds(50, 350, 150, 50);
        botaoMakeDocente.setBounds(250, 350, 150, 50);

        botaoVoltarListaDocentes.addActionListener(new docentesInformacao());
        botaoMakeDocente.addActionListener(new finalcriarDocenteListener());

        painelcriarDocente.add(labelCriarDocenteTitulo);
        painelcriarDocente.add(labelNome);
        painelcriarDocente.add(labelEmail);
        painelcriarDocente.add(labelMeca);
        painelcriarDocente.add(labelArea);

        painelcriarDocente.add(caixaNome);
        painelcriarDocente.add(caixaEmail);
        painelcriarDocente.add(caixaMeca);
        painelcriarDocente.add(caixaArea);

        painelcriarDocente.add(botaoVoltarListaDocentes);
        painelcriarDocente.add(botaoMakeDocente);

        panelPrincipal.removeAll();
        panelPrincipal.add(painelcriarDocente);
        panelPrincipal.updateUI();
    }


    private void finalizarDocente(){

        cisuc.listaDocentes.add(new Docente(Integer.parseInt(caixaMeca.getText()),caixaArea.getText(),caixaNome.getText(),caixaEmail.getText()));
        System.out.println(cisuc.listaDocentes.get(0).getNome());
    }


    private class verPerfisListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            botaoVerPerfis();
        }
    }

    private class docentesInformacao implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            botaoDocentes();
        }
    }

    private class voltarListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            paginaPrincipal();
        }
    }

    private class criarDocenteListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            botaoCriarDocente();
        }
    }

    private class finalcriarDocenteListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            finalizarDocente();
            botaoDocentes();
        }
    }


}










