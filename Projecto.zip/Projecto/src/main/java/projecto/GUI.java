/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projecto;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import javax.swing.*;

public class GUI {
    CISUC cisuc;

    public GUI(CISUC cisuc) {
        this.cisuc = cisuc;
    }

    int indexSelecionado;


    JFrame framePrincipal = new JFrame();
    /////////////
    JButton botaoListaBolseiros = new JButton("Listar Bolseiros");
    JButton botaoListaProjetos = new JButton("Listar Projetos");
    JButton botaoListaDocentes = new JButton("Listar Docentes");
    JButton botaoSaveExit = new JButton("Save and exit");
    ///////////////
    JButton botaoVerBolseiro = new JButton("Ver informações do perfil");
    JButton botaoCriarBolseiro = new JButton("Adicionar perfil");
    JButton botaoCriarDocente = new JButton("Adicionar Docente");
    JButton botaoVerDocente = new JButton("Ver informaçoes");
    JButton botaoVoltarPrincipal = new JButton("Voltar");
    ////////////////
    JButton botaoVoltarListaDocentes = new JButton("Voltar");
    JButton botaoMakeDocente = new JButton("Criar");
    ////////////////
    JList listaPrincipal = new JList(new DefaultListModel<>());


    ////////////////
    JTextField caixaNome = new JTextField(40);
    JTextField caixaEmail = new JTextField(40);
    JTextField caixaMeca = new JTextField(40);
    JTextField caixaArea = new JTextField(40);
    ////////////////
    JLabel labelVariavel1 = new JLabel();
    JLabel labelVariavel2 = new JLabel();
    JLabel labelVariavel3 = new JLabel();
    JLabel labelVariavel4 = new JLabel();
    JLabel labelNome = new JLabel("Nome:");
    JLabel labelEmail = new JLabel("Email:");
    JLabel labelMeca = new JLabel("Numero mecanográfico:");
    JLabel labelArea = new JLabel("Área de investigação:");
    JLabel labelCriarDocenteTitulo = new JLabel("Criar Docente:");
    ////////////////
    JScrollPane scrollerPrincipal = new JScrollPane(listaPrincipal);

    ////////////////
    JPanel panelPrincipal = new JPanel();
    ////////////////
    JPanel painelAbsolutoPrincipal = new JPanel(null);
    JPanel painelPerfilInformacao = new JPanel(null);
    JPanel painelDocentes = new JPanel(null);
    JPanel painelcriarDocente = new JPanel(null);
    JPanel painelEditarDocente = new JPanel(null);


    JList docenteLista;



    public void paginaPrincipal() {
        panelPrincipal.removeAll();
        panelPrincipal.setLayout(new BorderLayout());


        framePrincipal.setTitle("CISUC");
        framePrincipal.setSize(1200, 900);
        framePrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        botaoListaBolseiros.setBounds(400, 150, 400, 75);
        botaoListaDocentes.setBounds(400, 275, 400, 75);
        botaoListaProjetos.setBounds(400, 400, 400, 75);
        botaoSaveExit.setBounds(400, 675, 400, 75);

        botaoListaBolseiros.addActionListener(new listenerVerBolseiros());
        botaoListaDocentes.addActionListener(new listenerDocenteInformacao());

        painelAbsolutoPrincipal.add(botaoListaBolseiros);
        painelAbsolutoPrincipal.add(botaoListaDocentes);
        painelAbsolutoPrincipal.add(botaoListaProjetos);
        painelAbsolutoPrincipal.add(botaoSaveExit);

        panelPrincipal.add(painelAbsolutoPrincipal, BorderLayout.CENTER);

        framePrincipal.add(panelPrincipal);
        framePrincipal.setVisible(true);
        panelPrincipal.updateUI();
    }

    public void menuListarBolseiros() {
        scrollerPrincipal.setBounds(400, 150, 400, 450);
        botaoVerBolseiro.setBounds(400, 600, 400, 75);
        botaoCriarBolseiro.setBounds(400, 675, 400, 75);
        botaoVoltarPrincipal.setBounds(400, 750, 400, 75);

        botaoVoltarPrincipal.addActionListener(new listenerVoltar());

        painelPerfilInformacao.add(botaoVoltarPrincipal);
        painelPerfilInformacao.add(botaoVerBolseiro);
        painelPerfilInformacao.add(botaoCriarBolseiro);
        painelPerfilInformacao.add(scrollerPrincipal);

        panelPrincipal.removeAll();
        panelPrincipal.add(painelPerfilInformacao, BorderLayout.CENTER);
        panelPrincipal.updateUI();
    }

    public void menuListarDocentes() {
        botaoVoltarPrincipal.setBounds(400, 750, 400, 75);
        botaoVerDocente.setBounds(400, 600, 400, 75);
        botaoCriarDocente.setBounds(400, 675, 400, 75);

        botaoVoltarPrincipal.addActionListener(new listenerVoltar());
        botaoCriarDocente.addActionListener(new listenerCriarDocente());
        botaoVerDocente.addActionListener(new listenerEditarDocente());

        DefaultListModel listaDocenteObjetos = new DefaultListModel();
        this.docenteLista = new JList(listaDocenteObjetos);
        JScrollPane scrollerDocentes = new JScrollPane(this.docenteLista);

        listaDocenteObjetos.removeAllElements();

        for (Docente i:cisuc.listaDocentes
             ) {
            listaDocenteObjetos.addElement(i.getNome());

        }



        scrollerDocentes.setBounds(400, 150, 400, 450);
        this.docenteLista.setBounds(400,150,400,450);

        painelDocentes.add(scrollerDocentes);
        painelDocentes.add(botaoVoltarPrincipal);
        painelDocentes.add(botaoCriarDocente);
        painelDocentes.add(botaoVerDocente);

        panelPrincipal.removeAll();
        panelPrincipal.add(painelDocentes,BorderLayout.CENTER);
        painelDocentes.updateUI();
        panelPrincipal.updateUI();


    }

    public void menuCriarDocente() {
        labelCriarDocenteTitulo.setFont(new Font("Arial",0,20));

        labelCriarDocenteTitulo.setBounds(50, 50, 300, 50);
        labelNome.setBounds(50, 125, 50, 25);
        labelEmail.setBounds(50, 175, 50, 25);
        labelMeca.setBounds(50, 225, 150, 25);
        labelArea.setBounds(50, 275, 150, 25);

        caixaNome.setBounds(200, 125, 225, 25);
        caixaEmail.setBounds(200, 175, 225, 25);
        caixaMeca.setBounds(200, 225, 225, 25);
        caixaArea.setBounds(200, 275, 225, 25);

        botaoVoltarListaDocentes.setBounds(50, 350, 150, 50);
        botaoMakeDocente.setBounds(250, 350, 150, 50);

        botaoVoltarListaDocentes.addActionListener(new listenerDocenteInformacao());
        botaoMakeDocente.addActionListener(new listenerConfirmarDocente());

        painelcriarDocente.add(labelCriarDocenteTitulo);
        painelcriarDocente.add(labelNome);
        painelcriarDocente.add(labelEmail);
        painelcriarDocente.add(labelMeca);
        painelcriarDocente.add(labelArea);

        painelcriarDocente.add(caixaNome);
        painelcriarDocente.add(caixaEmail);
        painelcriarDocente.add(caixaMeca);
        painelcriarDocente.add(caixaArea);

        painelcriarDocente.add(botaoVoltarListaDocentes);
        painelcriarDocente.add(botaoMakeDocente);

        panelPrincipal.removeAll();
        panelPrincipal.add(painelcriarDocente);
        panelPrincipal.updateUI();
    }

    private void menuEditarDocente(Docente docente){
        labelVariavel1.setText(docente.getNome());
        labelVariavel2.setText(docente.getEmail());
        labelVariavel3.setText(new BigDecimal(docente.getNumeroMecanografico()).toPlainString());
        labelVariavel4.setText(docente.getAreaInvestigacao());

        labelVariavel1.setFont(new Font("Aral",0,40));
        labelVariavel2.setFont(new Font("Aral",0,20));
        labelVariavel3.setFont(new Font("Aral",0,20));
        labelVariavel4.setFont(new Font("Aral",0,20));
        labelEmail.setFont(new Font("Aral",0,20));
        labelMeca.setFont(new Font("Aral",0,20));
        labelArea.setFont(new Font("Aral",0,20));

        botaoVoltarListaDocentes.setBounds(75,300,200,100);

        labelVariavel1.setBounds(100,25,600,45);
        labelVariavel2.setBounds(320,100,600,30);
        labelVariavel3.setBounds(320,150,600,30);
        labelVariavel4.setBounds(320,200,600,30);
        labelEmail.setBounds(100,100,200,30);
        labelMeca.setBounds(100,150,230,30);
        labelArea.setBounds(100,200,200,30);

        botaoVoltarListaDocentes.addActionListener(new listenerVerBolseiros());

        painelEditarDocente.add(labelVariavel1);
        painelEditarDocente.add(labelVariavel2);
        painelEditarDocente.add(labelVariavel3);
        painelEditarDocente.add(labelVariavel4);
        painelEditarDocente.add(labelEmail);
        painelEditarDocente.add(labelMeca);
        painelEditarDocente.add(labelArea);

        painelEditarDocente.add(botaoVoltarListaDocentes);

        panelPrincipal.removeAll();
        panelPrincipal.add(painelEditarDocente);
        panelPrincipal.updateUI();

    }






    private void finalizarDocente(){

        cisuc.listaDocentes.add(new Docente(Integer.parseInt(caixaMeca.getText()),caixaArea.getText(),caixaNome.getText(),caixaEmail.getText()));
        System.out.println(cisuc.listaDocentes.get(0).getNome());
    }


    private class listenerVerBolseiros implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            menuListarBolseiros();
        }
    }

    private class listenerDocenteInformacao implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            menuListarDocentes();
        }
    }

    private class listenerVoltar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            paginaPrincipal();
        }
    }

    private class listenerCriarDocente implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            menuCriarDocente();
        }
    }

    private class listenerConfirmarDocente implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            finalizarDocente();
            menuListarDocentes();
        }
    }
    private class listenerEditarDocente implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            menuEditarDocente(cisuc.listaDocentes.get(docenteLista.getSelectedIndex()));
        }
    }


}










