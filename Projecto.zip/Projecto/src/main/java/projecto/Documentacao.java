package projecto;

public class Documentacao extends Tarefa{
    protected double taxaEsforco;

    public Documentacao(double taxaEsforco, Data inicio, double duracao, double taxaExecucao, Data fim, String pessoaResponsavel) {
        super(inicio, duracao, taxaExecucao, fim, pessoaResponsavel);
        this.taxaEsforco = 0.25;
    }


    
    
    
}
